<?php
header('Content-Type: Image/jpeg');
readfile('upload/pic.jpg');
?>
