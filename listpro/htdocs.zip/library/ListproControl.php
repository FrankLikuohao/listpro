<?php
//ListproControl.php
require_once 'library/ListproShowLib.php';
require_once 'library/ListproControlLib.php';
global $filterset;
global $initsearchkeyword;
if (isset($_POST['Go']))
{   
	
	  $filterset=getfilterset();
	  //echo "initsearchkeyword=[$initsearchkeyword]";
	  if ($initsearchkeyword === 1)$filterset[Checkboxfilter]='2';
		//echo "<br>initsearchkeyword=[$initsearchkeyword]";
	  //echo "<br>GO:filterset=";
	  //print_r($filterset);
	   //$conn=opendb();
	  //update_modify_with_file();
	  //update_modify_all(0);
	  //reflash();
		//mysql_close($conn);
}
if (isset($_POST['Finish']))
{   
	  $conn=opendb();
	  //update_modify_with_file();
	  update_modify_with_multi_file();
	  //update_modify_all(0);
	  //reflash();
		mysql_close($conn);
}
elseif (isset($_POST['Append']))
{   
	  $conn=opendb();
	   Append_modify_with_multi_file();
	  //update_modify_all(1);//1 insert 0 update -1 Delete
	  //reflash();
	  //echo "Append";
		mysql_close($conn);
}
/*elseif(isset($_POST['add']))
{
		  $conn=opendb();

	      //echo "_POST[";print_r($_POST);
		  //echo "_FILES['File']['tmp_name'][";print_r($_FILES['File']['tmp_name']);;
		  //exit;
		  
		  if($_POST['Iterms'] !== "") {
			  if($filename=$_FILES["File1"]["name"] !== ""){addIterms_pic(1);}
			  else{addIterms();}
		  }
	    //reflash();
		  mysql_close($conn);
		 
}*/
elseif(isset($_POST['add1']))
{

		  $conn=opendb();
	      //echo "_POST[";print_r($_POST);
		  //echo "_FILES['File']['tmp_name'][";print_r($_FILES['File']['tmp_name']);;
		  //exit;
		  
		  if($_POST['Iterms'] !== "") {
			  if($filename=$_FILES['File']['tmp_name'][0] !== ""){add_one_iterm_multi_pic();}
			  else{addIterms();}
		  }
	    //reflash();
		  mysql_close($conn);
		 
}

elseif(isset($_POST['UploadPicture']))
{
		
		   //<input type="submit" value="Upload..." name="UploadPicture"> 
		$tmpfilename=picupload();
		//echo"<br>Upload the filename=[$tmpfilename]";
		
		//$filename=tolinkaddressLocal($tmpfilename);
		//echo"<br>Upload Finish filename=[$filename]";
}
elseif(isset($_POST['checkBOM']))
{
		//<input type="submit" value="checkBOM" name="checkBOM">
		$UploadDir="AdditermData/";	
		$dirfile=$UploadDir .$_FILES["File1"]["name"];
		$result=checkBOM($dirfile);
		print "<br>$result";

}
/*elseif(isset($_POST['sizetest']))
{
		//print_r($_POST);
	$size=$_FILES["File1"]["size"] / 1024;
	printf (" Size: %d kB<br>",$size);
	//if($_POST['submitvalue'] === 'size' )
	$noreflash=1;
}
*/

elseif(isset($_POST['sizetest']))
{
	//print_r($_POST);
	$picktag='File';	
	foreach($_FILES[$picktag]['size'] as $key => $size){
	printf ("<br>%s(%d)kB",$_FILES[$picktag]['name'][$key] ,$size/1024);
	}
	$noreflash=0;
}
elseif (isset($_POST['update']))
{   
	  $conn=opendb();
		updatedb(1);
		//reflash();
		mysql_close($conn);
}
elseif (isset($_POST['SumSelect']))
{   
	  $conn=opendb();
		$sum=sum_select_iterms();
		//reflash();
		mysql_close($conn);
}
elseif (isset($_POST['UnCheck']))
{   
	  $conn=opendb();
		updatedb(0);
		//reflash();
		mysql_close($conn);
}
elseif (isset($_POST['UnFlag']))
{   
	  $conn=opendb();
		updateflagdb(0);
		//reflash();
		mysql_close($conn);
}
elseif (isset($_POST['Delete']))
{   
	  $conn=opendb();
		delete_select_iterms_show();
		//reflash();
		mysql_close($conn);
		$noreflash=1;
		$showadditerm=0;
}
elseif (isset($_POST['DeleteYes']))
{   
	  $conn=opendb();
		 Delete_Yes();
		//reflash();
		mysql_close($conn);
}
elseif (isset($_POST['No']))
{   
}
elseif (isset($_POST['Modify']))
{   
	  $conn=opendb();
		modify_show();
		//update_modify_all(0);
		$showadditerm=0;
		$noreflash=1;
		mysql_close($conn);
}

elseif (isset($_POST['ShowThisMonth']))
{   
	$noreflash=1;
	echo "<strong>Wait to do";
	//  $conn=opendb();

		 /*

Select * From todolist  Where DATE_SUB(CURDATE(), INTERVAL 7 DAY ) <= date(Date);

Select * From todolist  Where DATE_SUB(CURDATE(), INTERVAL 1 MONTH ) <= date(Date);
 */
     //$query = "Select * From todolist  Where DATE_SUB(CURDATE(), INTERVAL 1 MONTH ) <= date(Date) ORDER BY  `id` DESC   ";
     /* $query = "Select * From todolist  Where DATEDIFF(date(Date),CURDATE()) <1 and DATEDIFF(date(Date),CURDATE()) > -31 ORDER BY  `Date` DESC   ";
		 	//	 $query = "SELECT * FROM `todolist` ORDER BY  `id` DESC LIMIT 0, 150   ";
		  //echo "<br>query=[$query]";
		  $result=mysql_query($query) or die('Error, insert query failed 3'); 
		  $array=mysql_fetch_show_last($result,3);
		  $noreflash=1;
		mysql_close($conn);

*/
}
elseif (isset($_POST['ShowToday']))
{   
	 // echo"in ShowLastday";exit;
	  $conn=opendb();
      //$query = "Select * From todolist  Where DATE_SUB(CURDATE(), INTERVAL 1 DAY ) <= date(Date) ORDER BY  `id` DESC   ";
      $query = "Select * From todolist  Where DATEDIFF(date(Date),CURDATE()) = 0  ORDER BY  `Date` DESC   ";
	  $result=mysql_query($query) or die('Error, insert query failed 3'); 
		  $array=mysql_fetch_show_last($result,3);
		  $noreflash=1;
		mysql_close($conn);
}
elseif (isset($_POST['ShowLastDay']))
{   
	  //echo"in ShowLastday";exit;
	  $conn=opendb();
      //$query = "Select * From todolist  Where DATE_SUB(CURDATE(), INTERVAL 1 DAY ) <= date(Date) ORDER BY  `id` DESC   ";
      $query = "Select * From todolist  Where DATEDIFF(date(Date),CURDATE()) = -1 ORDER BY  `Date` DESC   ";
	  $result=mysql_query($query) or die('Error, insert query failed 3'); 
		  $array=mysql_fetch_show_last($result,3);
		  $noreflash=1;
		mysql_close($conn);
}
elseif (isset($_POST['ShowLastWeek']))
{   
	  $conn=opendb();
      $query = "Select * From todolist  Where DATEDIFF(date(Date),CURDATE()) <= 0 and DATEDIFF(date(Date),CURDATE()) >= -7 ORDER BY  `Date` DESC   ";
		 	//	 $query = "SELECT * FROM `todolist` ORDER BY  `id` DESC LIMIT 0, 150   ";
		  //echo "<br>query=[$query]";
		  $result=mysql_query($query) or die('Error, insert query failed 3'); 
		  $array=mysql_fetch_show_last($result,3);
		  $noreflash=1;
		mysql_close($conn);
}
elseif (isset($_POST['ShowLastMonth']))
{   
	  $conn=opendb();

	    $query = "Select * From todolist  Where DATEDIFF(date(Date),CURDATE()) <=0 and DATEDIFF(date(Date),CURDATE()) >= -31 ORDER BY  `Date` DESC   ";
		 	//	 $query = "SELECT * FROM `todolist` ORDER BY  `id` DESC LIMIT 0, 150   ";
		  //echo "<br>query=[$query]";
		  $result=mysql_query($query) or die('Error, insert query failed 3'); 
		  $array=mysql_fetch_show_last($result,3);
		  $noreflash=1;
		mysql_close($conn);
}
elseif (isset($_POST['Searchbottom']))
{   
	  $conn=opendb();
		 $query = "SELECT * FROM `todolist` LIMIT 0, 300 ";
		  //echo "<br>query=[$query]";
		  $result=mysql_query($query) or die('Error, insert query failed 3'); 
		  $array=mysql_fetch_all_filter_show($result,3);
		mysql_close($conn);
		 $noreflash=1;
}

elseif (isset($_POST['reflash']))
{   
	 reflashall(); $noreflash=1;
}
else
{}
//$sql = "SELECT * FROM `todolist` WHERE `Checkbox` = 1 LIMIT 0, 30 ";
//$sql = "SELECT * FROM `todolist` LIMIT 0, 30 ";
//$sql = "INSERT INTO `listpro`.`todolist` (`Checkbox`, `Flag`, `Iterms`, `Where`, `Notes`, `Date`) VALUES (\'0\', \'1\', \'®³¦çªA\', \'°ªº¸¤Ò\', \'·Ç³ÆÀ³¸Õ\', CURRENT_DATE());";
if($noreflash==1){$noreflash=0;}
	else reflashall();
?>
