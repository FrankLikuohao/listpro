<?php
function hi()
{
	echo "<strong>Hollo World</strong>";
}
function checkBOM ($filename) {
	//print "<br>in checkBOM filename=[$filename]";
    //global $auto;
    $contents = file_get_contents($filename);
    $charset[1] = substr($contents, 0, 1); 
    $charset[2] = substr($contents, 1, 1); 
    $charset[3] = substr($contents, 2, 1); 
    if (ord($charset[1]) == 239 && ord($charset[2]) == 187 && ord($charset[3]) == 191) {
    //if ($auto == 1) {
        $rest = substr($contents, 3);
        rewrite ($filename, $rest);
        return ("BOM found, automatically removed.");
    //} else {
    //    return ("BOM found.");
    //}
    } 
    else return ("BOM Not Found.");
}
function rewrite ($filename, $data) {
    $filenum = fopen($filename, "w");
    flock($filenum, LOCK_EX);
    fwrite($filenum, $data);
    fclose($filenum);
}
function IpFrom()
{
if (!empty($_SERVER['HTTP_CLIENT_IP']))
    $ip=$_SERVER['HTTP_CLIENT_IP'];
else if (!empty($_SERVER['HTTP_X_FORWARDED_FOR']))
    $ip=$_SERVER['HTTP_X_FORWARDED_FOR'];
else
    $ip=$_SERVER['REMOTE_ADDR'];
 
 //print "ip from =[$ip]<br>";
 return($ip);
}

function updatedb($setCheckboxValue)
{
	if(sizeof($_POST)<2) return;
	

mysql_select_db($dbname);

//print_r($_POST);
$updateiterms = $_POST['checkiterms'];
if(sizeof($updateiterms)<1) return;
//$colors = array(1, 2, 3, 4);
foreach($updateiterms as &$selectid){
	//  print"$selectid";
	  $query="UPDATE `todolist` SET `Checkbox`=$setCheckboxValue WHERE  id = $selectid ";

//echo "<br>query=[$query]";
mysql_query($query) or die('Error, update select id');
}
}
function updateflagdb($setFlagValue)
{
	if(sizeof($_POST)<2) return;
	

mysql_select_db($dbname);

//print_r($_POST);
$updateiterms = $_POST['checkflag'];
//$colors = array(1, 2, 3, 4);
foreach($updateiterms as &$selectid){
	//  print"$selectid";
	  $query="UPDATE `todolist` SET `Flag`=$setFlagValue WHERE  id = $selectid ";

//echo "<br>query=[$query]";
mysql_query($query) or die('Error, update select id');
}
}

function mysql_fetch_all($res) {
   while($row=mysql_fetch_array($res)) {
       $return[] = $row;
       //print_r($row);
      echo $MakeHTML = "<br>$row[0], $row[1], $row[2],$row[3],$row[4],$row[5]";
     }
   return $return;
}


function days_diff_today($recordday)
{
	$myday=explode("-",$recordday);
	$today = getdate();
	//print_r($myday);print_r($today);
	$diffday=($myday[0]-$today[year])*365+  ($myday[1]-$today[mon]) * 30 + $myday[2]-$today[mday];
	return($diffday);
}
function NotePresentChangeIP($myNotes)
{
		global $ipfrom;//=IpFrom();
	if(strpos($ipfrom,'192.168') !== false) {
		//print "<br>Note no change";
	}
	else{
		$myNotes=str_replace('192.168.1.101','1.34.130.91',$myNotes);
		}
	//print "<br> ipfrom=[$ipfrom]  mynote=[$myNotes]";
	return($myNotes);
}
function NoteProcess($Notes)
{
	$check=0;  //level  3 2 1 less error   0 no erro
	if(strpos($Notes,'http:') === false)
	{
		$Notes=str_replace('"','\"',$Notes);
		$Notes='"'. $Notes .'"';
		return $Notes;
	}
	
	if ($check >0)print "<hr><strong>NoteProcess($Notes)</strong>";
	$orgNotes=$Notes;
	$Notes=$Notes . ' ';// for using function stristr() if no end of $Notes for cut string   
	
	//default no change;
	//print "Notes=$Notes]";
	// http://cline1413.pixnet.net/blog/post/221458400 ==>
	//<a href=http://cline1413.pixnet.net/blog/post/221458400>name<\a>
	
	$httpstrarray= explode(' ',$Notes);
	$httpstrarray[sizeof($httpstrarray)-1]="reference";//add ' ' at end replace as reference
	if ($check>0) print_r($httpstrarray);
	for ($i=0;$i<sizeof($httpstrarray)-1;$i++){
		$tmpstr=$httpstrarray[$i];
		if(strpos($tmpstr,'http') === false){
			$tmpNotes=$tmpNotes . $tmpstr . ' ';
			continue;
		}
		$nochange=1;
		$orgtmpstr=$tmpstr;
		
		if(strpos($tmpstr,'http://') !== false){
			$httpbefore=stristr($tmpstr, 'http://',true);
			$httpbegin=stristr($tmpstr, 'http://');
			$nochange=0;
			if ($check >0)print "<br>find 1";
		}
		if(strpos($tmpstr,'https://') !== false){
			$httpbefore=stristr($tmpstr, 'https://',true);
			$httpbegin=stristr($tmpstr, 'https://');
			$nochange=0;
			if ($check >0) print "<br>find 2";
		}
		if (strpos($tmpstr,'href=http://')!== false ){
			$nochange=1;//avoid insert " 
			if ($check >0) print "<br>find 3";
		}
		if (strpos($tmpstr,'src=http://')!== false ){
			$nochange=1;//avoid insert " 
			if ($check >0) print "<br>find 4";
		}
		/*
		$httpstr=stristr($httpbegin,' ',true);
		$httplast=stristr($httpbegin, ' ');
		
		$httplast=substr("$httplast", 1);// cut a ' ';
		$httplast=$httplast .' ';//avoid not ' ' after the name str
		$name=stristr($httplast, ' ',true);
		$httplast=stristr($httplast, ' ');
		*/
		 if($nochange==0){
			$tmpstr='<a href=' . $tmpstr . '>' . $httpstrarray[$i+1] . '</a> ';
			$i++;
			}
		 else {$tmpstr=$orgtmpstr;}
		 if ($check >0) echo "<br>tmpstr[$i]=[$tmpstr]";
		 $tmpNotes=$tmpNotes . $tmpstr . ' ';//explode reomce
		}	
	
	//if ($name == "") $name="Reference";
	//$name='"'. $name . '"';	
	//if ($check >2) print "<br>httpnote=[$Notes]";
	
    /*if($nochange==0){
		$Notes=$httpbefore . '<a href=' . $httpstr . '>' . $name . '</a> ' . $httplast ;
	}
	else {$Notes=$orgNotes;}//skip href=http:  ,  img src=http:
	*/
	$Notes=$tmpNotes;
	$Notes=str_replace('"','\"',$Notes);
	$Notes='"'. $Notes .'"';
	/*if ($check >1) 
	print "<br>nochange=[$nochange]
		   <br>httpbefore=[$httpbefore]
		   <br>httpbegin=[$httpbegin]
		   <br>httpstr[$httpstr]
		   <br>httplast=[$httplast] 
		   <br>name=[$name]
		   <br>Notes=[$Notes]";
	*/	
	return $Notes;
}
/*
function NoteProcess($Notes)
{
	$nochange=1;//default no change;
	//print "Notes=$Notes]";
	// http://cline1413.pixnet.net/blog/post/221458400 ==>
	//<a href=http://cline1413.pixnet.net/blog/post/221458400>name<\a>
	if(strpos($Notes,'http://') !== false){
		$httpbefore=stristr($Notes, 'http://',true);
		$httpbegin=stristr($Notes, 'http://');
		$nochange=0;
		//print "<br>find 1";
	}
	if(strpos($Notes,'https://') !== false){
		$httpbefore=stristr($Notes, 'https://',true);
		$httpbegin=stristr($Notes, 'https://');
		$nochange=0;
		//print "<br>find 2";
	}
	if (strpos($Notes,'href=http://')!== false ){
		$nochange=1;//avoid insert " 
		//print "<br>find 3";
	}
	if (strpos($Notes,'src=http://')!== false ){
		$nochange=1;//avoid insert " 
		//print "<br>find 4";
	}
	
	$httpstr=stristr($httpbegin,' ',true);
	$httplast=stristr($httpbegin, ' ');
	
	$httplast=substr("$httplast", 1);// cut a ' ';
	$httplast=$httplast .' ';//avoid not ' ' after the name str
	$name=stristr($httplast, ' ',true);
	$httplast=stristr($httplast, ' ');
	
	if ($name == "") $name="Reference";
	$name='"'. $name . '"';	
	//print "<br>httpnote=[$Notes]";
	
    if($nochange==0){$Notes=$httpbefore . '<a href=' . $httpstr . '>' . $name . '</a> ' . $httplast ;$Notes=$httpbefore . '<a href=' . $httpstr . '>' . $name . '</a> ' . $httplast ;}//skip href=http://
	
	$Notes=str_replace('"','\"',$Notes);
	$Notes='"'. $Notes .'"';
	//print "[$nochange][$httpbefore][$httpbegin] [$httpstr] [$httplast] [ $name]<br>Notes=[$Notes]";
	//exit;	
	return $Notes;
}
*/

function opendb()
{// This is an example of config.php
$dbhost = 'localhost';
$dbuser = 'lgh';
$dbpass = 'frank';
$dbname = 'listpro';

// This is an example opendb.php
//So now you can open a connection to mysql like this :
$conn = mysql_connect($dbhost, $dbuser, $dbpass) or die('Error connecting to mysql');
mysql_select_db($dbname);
//echo "<br>select db [ $dbname ]";
return $conn;
}
function picMultiupload_name($picktag,$key,$destname)
{
	//$picktag="File1";
$UploadDir="AdditermData/";	
$dirfile=$UploadDir .$destname;
//print_r($_POST);
//print_r($_FILES);
$allowedExts = array("gif", "jpeg", "jpg", "png");
$filename=$_FILES[$picktag]["name"];
//echo "filename=[$filename]";
$temp = explode(".", $_FILES[$picktag]["name"][$keys]);
$extension = end($temp);
$size=$_FILES[$picktag]["size"][$key] / 1024;


if($_POST['submitvalue'] === 'size' )exit;
  if ($_FILES[$picktag]["error"][$key] > 0)
    {
    echo "Return Code: " . $_FILES[$picktag]["error"][$key] . "<br>";
    }
  else
    {
//    echo "Upload: " . $_FILES["File1"]["name"] . "<br>";
 //   echo "Type: " . $_FILES["File1"]["type"] . "<br>";
    //echo "Size: " .  $size .  "kB<br>";
//    echo "Temp file: " . $_FILES["File1"]["tmp_name"] . "<br>";

    if (file_exists($dirfile))
      {
      echo $dirfile . " already exists. ";
      }
    else
      {
      move_uploaded_file($_FILES[$picktag]["tmp_name"][$key],
      $dirfile );
      $result=checkBOM ( $dirfile) ;
     // print "<br>checkBOMresult=$result";
      echo "<br>Stored in: " .$dirfile;
      printf ("[%d]kB",$size);
      
      return ( $dirfile);
      }
    }
}
/*function ()
{
		foreach($_FILES['File']['tmp_name'] as $key => $tmpName) {

		  $file_name = $_FILES['File']['name'][$key];
		  $file_type = $_FILES['File']['type'][$key];
		  $file_size = $_FILES['File']['size'][$key];
		  $file_tmp  = $_FILES['File']['tmp_name'][$key];
		  //$filename=$lastid.'_'.$key.time();
		  $filename=$lastid.'_'.$key;
		  $refnameLocal=UploadMultiFileGetLinkName('File',$key,$filename);
		 //$refnameLocal=UploadFileGetLinkName("$files[$i]",$filename);
                $NoteAppendRefname=$NoteAppendRefname . "(" .$refnameLocal .")" . ' ';
        }
     
}*/
function UploadMultiFileGetLinkName($picktag,$lastid)
{
	//print_r($_FILES);
	//echo "<br>picktag=[$picktag]";
	mutiFileUpload($picktag);
	foreach($_FILES[$picktag]['name'] as $key => $filename) {
				//echo"<br>filename=$filename";
				$newname=$lastid .'_'.$key. '_'. time();
				//echo"<br>newname=$newname";				
				$temp = explode(".", $filename);
				$extension = end($temp);							
				$uploadname=$newname .".$extension";
				$tmpfilename=picMultiupload_name($picktag,$key,$uploadname);
			    $refnameLocal=tolinkaddressLocal($tmpfilename);
			    //$refnameWWW=tolinkaddressWWW($tmpfilename);
			    //$NoteAppendRefname=$_POST['Notes'] . $refnameWWW ."(" .$refnameLocal .")";
			     $NoteAppendRefname=$NoteAppendRefname . "(" .$refnameLocal .")" . ' ';
	}
      return   array($NoteAppendRefname,$key+1);
}
function UploadMultiFileGetLinkName_old($picktag,$key,$lastid)
{
						$filename=$_FILES[$picktag]["name"][$key];
		
						//echo "filename=[$filename]";
						//$temp = explode(".", $_FILES["File1"]["name"]);
						$temp = explode(".", $filename);
						$extension = end($temp);							
				$uploadname=$lastid . ".$extension";
				$tmpfilename=picMultiupload_name($picktag,$key,$uploadname);
			    $refnameLocal=tolinkaddressLocal($tmpfilename);
			    //$refnameWWW=tolinkaddressWWW($tmpfilename);
			    //$NoteAppendRefname=$_POST['Notes'] . $refnameWWW ."(" .$refnameLocal .")";
      return $refnameLocal;
}
/*function tolinkaddressLocal($tmpfilename)
{
	// note add
	//<a href=http://192.168.1.101:6001/downloadurl.php?f=upload/my.txt>upload/my.txt</a> 
	//$picDir= 'upload/';
	//$tmpfilename = $dir . $tmpfilename;
	//<img src="upload/66-1.jpg" width="16" height="12" alt="text" />
	$filename='<img src=http://192.168.1.101:6001/'. "$tmpfilename" . ' width=16 height=12 alt=text />';
	//$filename='<a href=http://192.168.1.101:6001/downloadurl.php?f='. "$tmpfilename" . '>' ."Local"  .'</a>';
	//print"[tmpfilename=$tmpfilename] imgfilename=[$filename]";
	return($filename);
}*/
function tolinkaddressWWW($tmpfilename)
{
	// note add
	//<a href=http://192.168.1.101:6001/downloadurl.php?f=upload/my.txt>upload/my.txt</a> 
	//$picDir= 'upload/';
	//$tmpfilename = $dir . $tmpfilename;
	//$filename='<a href=http://1.34.130.91:6001/downloadurl.php?f='. "$tmpfilename" . '>' ."$tmpfilename"  .'</a>';
	$filename='<img src=http://1.34.130.91:6001/'. "$tmpfilename" . ' width=16 height=12 alt=text />';
	print"[tmpfilename=$tmpfilename] imgwwwfilename=[$filename]";
	return($filename);
}
function tolinkaddressLocal($tmpfilename)
{
	// note add
	//<a href=http://192.168.1.101:6001/downloadurl.php?f=upload/my.txt>upload/my.txt</a> 
	//$picDir= 'upload/';
	//$tmpfilename = $dir . $tmpfilename;
	//<img src="upload/66-1.jpg" width="16" height="12" alt="text" />
	$filename='<img src=http://192.168.1.101:6001/'. "$tmpfilename" . ' width=16 height=12 alt=text />';
	//$filename='<a href=http://192.168.1.101:6001/downloadurl.php?f='. "$tmpfilename" . '>' ."Local"  .'</a>';
	//print"[tmpfilename=$tmpfilename] imgfilename=[$filename]";
	return($filename);
}	
function mutiFileUpload($filepostname)
{ 
	foreach($_FILES[$filepostname]['tmp_name'] as $key => $tmpName) {

		  $file_name = $_FILES[$filepostname]['name'][$key];
		  $file_type = $_FILES[$filepostname]['type'][$key];
		  $file_size = $_FILES[$filepostname]['size'][$key];
		  $file_tmp  = $_FILES[$filepostname]['tmp_name'][$key];
		  print "<br>File[$keys]>$filename=[$file_name],filetype=[$file_type],file_size=[$file_size],filetmpname=[$file_tmp]"; 
		  
	  //move_uploaded_file($file_tmp,"files/".time().$file_name);
		}
}
function picupload_name($picktag,$destname)
{
	//$picktag="File1";
$UploadDir="AdditermData/";	
$dirfile=$UploadDir .$destname;
//print_r($_POST);
//print_r($_FILES);
$allowedExts = array("gif", "jpeg", "jpg", "png");
$filename=$_FILES[$picktag]["name"];
//echo "filename=[$filename]";
$temp = explode(".", $_FILES[$picktag]["name"]);
$extension = end($temp);
$size=$_FILES[$picktag]["size"] / 1024;
printf (" Size: %d kB<br>",$size);

if($_POST['submitvalue'] === 'size' )exit;
  if ($_FILES[$picktag]["error"] > 0)
    {
    echo "Return Code: " . $_FILES[$picktag]["error"] . "<br>";
    }
  else
    {
//    echo "Upload: " . $_FILES["File1"]["name"] . "<br>";
 //   echo "Type: " . $_FILES["File1"]["type"] . "<br>";
    //echo "Size: " .  $size .  "kB<br>";
//    echo "Temp file: " . $_FILES["File1"]["tmp_name"] . "<br>";

    if (file_exists($dirfile))
      {
      echo $dirfile . " already exists. ";
      }
    else
      {
      move_uploaded_file($_FILES[$picktag]["tmp_name"],
      $dirfile );
      $result=checkBOM ( $dirfile) ;
     // print "<br>checkBOMresult=$result";
      echo "Stored in: " .$dirfile;
      
      return ( $dirfile);
      }
    }
}
function picupload()
{
$UploadDir="upload/";	
//print_r($_POST);
//print_r($_FILES);
$allowedExts = array("gif", "jpeg", "jpg", "png");
$filename=$_FILES["File1"]["name"];
echo "filename=[$filename]";
$temp = explode(".", $_FILES["File1"]["name"]);
$extension = end($temp);
$size=$_FILES["File1"]["size"] / 1024;
printf (" Size: %d kB<br>",$size);

if($_POST['submitvalue'] === 'size' )exit;
  if ($_FILES["File1"]["error"] > 0)
    {
    echo "Return Code: " . $_FILES["File1"]["error"] . "<br>";
    }
  else
    {
    echo "Upload: " . $_FILES["File1"]["name"] . "<br>";
    echo "Type: " . $_FILES["File1"]["type"] . "<br>";
    //echo "Size: " .  $size .  "kB<br>";
    echo "Temp file: " . $_FILES["File1"]["tmp_name"] . "<br>";

    if (file_exists($UploadDir . $_FILES["File1"]["name"]))
      {
      echo $_FILES["File1"]["name"] . " already exists. ";
      }
    else
      {
	  move_uploaded_file($_FILES["File1"]["tmp_name"],
      $UploadDir . $_FILES["File1"]["name"]);
      //echo "Stored in: " . $UploadDir . $_FILES["File1"]["name"];
      $dirfile=$UploadDir . $_FILES["File1"]["name"];
      $result=checkBOM ( $dirfile) ;
      //print "<br>checkBOMresult=$result";
      return ( $dirfile);
      }
    }
}
function getfilterset()
{
	global $initsearchkeyword;
  // Array ( [Checkfilter] => on [Flagfilter] => on [Textfilter] => 123 [Pricefilter] => 1 [Datefilter] => 2 ) 
  //print "<br> getfilterset:_POST";
  //print_r($_POST);
  global $filterset;
  $filterset=array( 'Checkboxfilter' =>$_POST[Checkboxfilter] ,
                    'Flagfilter'  => $_POST[Flagfilter],
                     'Textfilter' => $_POST[Textfilter],
                     'Pricefilter'=> $_POST[Pricefilter],
                     'Datefilter' => $_POST[Datefilter]); 
 if($filterset[Checkboxfilter] === "")$filterset[Checkboxfilter]='BOTH';//laststat ; else $filterset[Checkfilter]=0;
 if($filterset[Flagfilter] === "" )$filterset[Flagfilter]='BOTH'; //else $filterset[Flagfilter]=0;
 // if($filterset[Datefilter] === 'on')$filterset[Flagfilter]=1; else $filterset[Flagfilter]=0;
  $filterset[Textfilter]=$_POST[Textfilter]; 
 if($filterset[Textfilter] !== "") {$initsearchkeyword=1;}//good to view 
 
  //print "<br> getfilterset:filterset";
 //print_r($filterset);
  return $filterset;	
}
?>

