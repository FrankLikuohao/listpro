<?php
// This is an example of config.php
$dbhost = 'localhost';
//$dbuser = 'root';
//$dbpass = 'password';
//$dbname = 'phpcake';
$dbuser = 'lgh';
$dbpass = 'frank';
$dbname = 'lgh';

?>
