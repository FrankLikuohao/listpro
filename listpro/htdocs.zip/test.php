<?php
$Notes='(<img src=http://192.168.1.101:6001/AdditermData/965_0.jpg width=16 height=12 alt=text />) (<img src=http://192.168.1.101:6001/AdditermData/965_1.jpg width=16 height=12 alt=text />) (<img src=http://192.168.1.101:6001/AdditermData/965_2.jpg width=16 height=12 alt=text />) (<img src=http://192.168.1.101:6001/AdditermData/965_3.jpg width=16 height=12 alt=text />) (<img src=http://192.168.1.101:6001/AdditermData/965_4.jpg width=16 height=12 alt=text />) (<img src=http://192.168.1.101:6001/AdditermData/965_5.jpg width=16 height=12 alt=text />)  ';
print"<br>input notes =[$Notes]";
$imgfinenames=getimgsname($Notes);
echo "<br>imagesname=[";print_r($imgfinenames);
function getimgsname($Notes)
{
		$string=explode(' ',$Notes);
		//print_r($string);
		foreach ($string as &$word)
		{
			if(strpos($word,'src=http://192.168.1.101:6001/')!== false ){
			$imgbegin=stristr($word, 'AdditermData/');
			$names[] = $imgbegin;
			//$imgfilename[]=stristr($imgbegin,'',ture);
			//echo "imagebegin=[$imgbegin] delete file[$imgfilename]";
			}
			else{continue;}
		}
		return $names;
};
	
?>
 
