﻿
<?php
$var = "put reflash on last line before every if else, that will make it run after every click's function like \"event flow\" but there is form conflict by 2 same form1.Thus Modify function use head2 which has form 2 solved the problem";
echo "Original: $var<hr />\n";

/* These two examples replace all of $var with 'bob'. */
echo str_replace('"','\"',$var) . "<br />\n" .$unknow;

?>